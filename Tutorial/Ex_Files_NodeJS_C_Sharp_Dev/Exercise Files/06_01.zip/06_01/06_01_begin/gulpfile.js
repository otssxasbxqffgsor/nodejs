const gulp = require("gulp");
const babel = require("gulp-babel");
const debug = require("gulp-debug");

gulp.task("build", () => {
    return gulp.src("src/**/*.js")
        .pipe(debug())
        .pipe(babel({
            "presets":["es2015"]
        }).on("error", (err) => {
            console.log(`An error occurred: ${err}`);
        }))
        .pipe(gulp.dest("compiled"));
});