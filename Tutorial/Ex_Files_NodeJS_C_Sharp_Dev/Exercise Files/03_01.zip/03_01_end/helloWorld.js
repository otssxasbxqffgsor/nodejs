class HelloWorld {
    sayHello() {
        console.log("Hello world 5");
    }
}

module.exports = HelloWorld;