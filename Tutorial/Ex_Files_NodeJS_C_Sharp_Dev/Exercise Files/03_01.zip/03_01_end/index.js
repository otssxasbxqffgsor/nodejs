const meaningless = require('./helloWorld');

new meaningless().sayHello();


